<?php

namespace Source\Loading;

class User
{

}