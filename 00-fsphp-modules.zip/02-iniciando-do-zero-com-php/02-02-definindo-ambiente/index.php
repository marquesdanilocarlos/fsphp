<?php

require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("Definindo ambiente");

/*
 * 
 */
fullStackPHPClassSession("Sessão de debug", __LINE__);
var_dump($_SERVER);