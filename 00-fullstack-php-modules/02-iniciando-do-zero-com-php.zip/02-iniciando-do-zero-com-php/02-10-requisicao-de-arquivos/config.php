<?php

const COURSE = "FSPHP";
